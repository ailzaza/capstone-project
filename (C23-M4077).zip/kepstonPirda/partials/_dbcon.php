<?php
$connect=mysqli_connect("localhost","root","","projek") or die(mysqli_error($connection))
?>